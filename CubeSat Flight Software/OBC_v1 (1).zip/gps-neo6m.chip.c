  #include "wokwi-api.h"
  #include <stdio.h>
  #include <stdlib.h>
  #include <string.h>    // contains strlen() function

  #define LEN(arr) ((int)(sizeof(arr) / sizeof(arr)[0]))    // macro

  #define SECOND 1000000    // micros

  // A NMEA 0183 sentence can have a maximum of 80 characters plus a
  // carriage return and a line feed

// Replace the massive gps_tx_data array with a smaller set
const char* gps_tx_data[] = {
  "$GPRMC,172914.049,A,2327.985,S,05150.410,W,009.7,025.9,060622,000.0,W*74\r\n",
  "$GPGGA,172914.049,2327.985,S,05150.410,W,1,12,1.0,0.0,M,0.0,M,,*60\r\n"
};


  typedef struct {
    uart_dev_t uart0;
    uint32_t   gps_tx_index;
  } chip_state_t;


  static void chip_timer_event  (void *user_data);


  void chip_init(void) {

    setvbuf(stdout, NULL, _IOLBF, 1024);                // ???     // Disable buffering for debug logs

    chip_state_t *chip = malloc(sizeof(chip_state_t));

    const uart_config_t uart_config = {
      .tx         = pin_init("TX", INPUT_PULLUP),
      .rx         = pin_init("RX", INPUT),
      .baud_rate  = 9600,
      .user_data  = chip,
    };

    chip->uart0        = uart_init(&uart_config);
  
    chip->gps_tx_index = 0;

    const timer_config_t timer_config = {
      .callback  = chip_timer_event,
      .user_data = chip,
    };

    timer_t timer = timer_init(&timer_config);

    timer_start(timer, SECOND, true);

    printf("GPS Chip initialized!\n");         // prints to web browser console (developer tools)

  }

  void chip_timer_event(void *user_data) {

    chip_state_t *chip = (chip_state_t*) user_data;

    printf("chip_timer_event\n");

    const char * message = gps_tx_data[chip->gps_tx_index++];

    uart_write(chip->uart0, (uint8_t *) message, strlen(message));

    if (chip->gps_tx_index >= LEN(gps_tx_data)) {       
      chip->gps_tx_index = 0;
    }
  }
